### v1.0.0

Initial release!

## v1.1.0

Extended fix to shotguns, credit to randomuserhi!

## v1.2.0

Extended fix to shotgun spread, credit to Dinorush!

## v1.2.1

Added a fix for possible infinite loop, credit to Dinorush!
