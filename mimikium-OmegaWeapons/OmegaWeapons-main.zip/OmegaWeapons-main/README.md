# OmegaWeapons
A weapon rebalance mod balanced around Vanilla and similar difficulty custom rundowns (such as Variable Delta). Massive credit goes to Tru's Vanilla Reloaded mod for inspiration and some of the changes.
